
# Datepicker Console-Style (Click to Run: disneyworld.disney.go.com)

Targets the cross-origin iframe at **https://disneyworld.disney.go.com/** by declaring it in **host_permissions**.
Click the toolbar button to inject the console-style scanner into **all frames** of the current tab.

## Install
1. `chrome://extensions` → enable **Developer mode**.
2. **Load unpacked** (select this folder).
3. Open your target page and **click the extension's toolbar button**.
4. See output in DevTools → **Console**.

## Why host_permissions?
`activeTab` alone cannot inject into **cross-origin iframes**. Declaring
`"host_permissions": ["https://disneyworld.disney.go.com/*"]` gives the extension explicit access to inject into that frame.

## Notes
- Sandboxed iframes without `allow-scripts` still cannot be scripted (you'll see them under "Inaccessible frames").
- The code is your original console IIFE with a short retry to catch late hydration.
