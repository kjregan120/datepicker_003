
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ["scan.js"]
    });
  } catch (e) {
    console.error("Injection failed:", e);
  }
});
