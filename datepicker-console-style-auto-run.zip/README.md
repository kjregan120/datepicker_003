
# Datepicker Console-Style (Auto Run)

This content script executes a near-identical version of your console IIFE **automatically** on matching pages, only in the **top frame**. It recursively scans accessible iframes and reports blocked ones—just like your snippet.

- No background/service worker.
- No cross-frame messaging.
- Behavior matches the console run as closely as possible.

## Install
1. Go to `chrome://extensions`, enable **Developer mode**.
2. **Load unpacked** → select this folder.
3. Navigate to a matching page and open DevTools → Console to see output.

## Notes on *why any deviation might be needed*
- Content scripts run in an *isolated world*. We keep your code as-is; we only note that `window.__pickerRanges` is stored in the content script's world (not the page JS). If a page script needs it, you'd inject a <script> tag, but for Console usage that's not necessary.
- Access to **cross-origin or sandboxed iframes** is still blocked by the browser; we catch and list them in `blocked`, same as your console code.
- If you prefer, you can narrow/expand the URL matches in `manifest.json`.
