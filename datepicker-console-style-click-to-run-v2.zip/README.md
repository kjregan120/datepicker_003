
# Datepicker Console-Style (Click to Run, All Frames + Retry)

**Closest to your console script:** click the toolbar button to inject the IIFE into **all frames** of the current tab.
It runs immediately and will **retry for ~6 seconds** if nothing is found (helps with late hydration).

## Install
1. Open `chrome://extensions`, enable **Developer mode**.
2. Click **Load unpacked** and select this folder.
3. Open your target page, then **click the extension's toolbar button**.
4. Open DevTools → **Console** to see the output.

## Notes
- Injects into **all frames**, so if the picker lives inside an iframe that’s same-origin, it runs directly there.
- Cross-origin or sandboxed iframes remain inaccessible (they’ll appear in the “Inaccessible frames” table).
- No host permissions needed (uses `activeTab` + `scripting`). Click again anytime to rerun.
