
# Datepicker Console-Style (Click to Run)

This version is the **closest to your console snippet**. It doesn't run until you click the extension's toolbar button, then it injects and runs the exact IIFE in the **top frame only**. The code recursively scans accessible iframes and prints results just like the console version.

## Install
1. Go to `chrome://extensions`, enable **Developer mode**.
2. **Load unpacked** → select this folder.
3. Open your target page, click the extension's toolbar button, then check DevTools → Console.

## Why this is closest to console usage
- No `host_permissions` are requested (uses `activeTab`).
- No automatic page injection; it runs only when you ask.
- The IIFE is the same logic as your console script.

## Notes
- Cross-origin/sandboxed iframes remain inaccessible; they are listed in the `blocked` table like in your snippet.
- If you want to inject into *all frames* instead of relying on recursion, change `allFrames: true` in `bg.js` (not usually needed here).
