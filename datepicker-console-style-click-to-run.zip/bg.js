
chrome.action.onClicked.addListener((tab) => {
  if (!tab?.id) return;
  // Inject ONLY in the top frame; the script scans reachable iframes itself.
  chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: false },
    files: ["scan.js"]
  });
});
